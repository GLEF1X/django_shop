import asyncio
from dataclasses import dataclass
from itertools import repeat
from typing import Literal, Optional, Union, Dict, List, Tuple, Any
from aiohttp import ClientTimeout, ClientSession, ContentTypeError
from aiohttp.client import DEFAULT_TIMEOUT


@dataclass(frozen=True)
class Response:
    status_code: int
    response_data: Union[
        Optional[Union[dict, str, bytes, bytearray]]
    ]


class RequestAuthError(Exception):
    """
    Ошибка при неправильной аунтефикации POST or GET data

    """


class HttpBase(object):
    """
    Class, which include abstract methods of parser

    """


class HttpXParser(HttpBase):
    """
    Парсер для django сайта, собирает дополнительную информацию

    """
    _sleep_time = 2

    def __init__(self):
        self._base_headers = {
            'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.90 Safari/537.36',
            'Accept-Language': "ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7",
            # 'Accept': 'application/json, text/plain, */*',
        }
        self._session: Optional[ClientSession] = None
        self.url = 'http://127.0.0.1/api/'
        self._timeout = ClientTimeout(total=2 * 15, connect=None, sock_connect=5, sock_read=None)

    async def _request(
            self,
            url: Optional[str] = None,
            get_json: bool = False,
            validate_django: bool = False,
            method: Literal['POST', 'GET'] = 'POST',
            set_timeout: bool = True,
            data: Optional[Dict[str, Union[str, int, List[Union[str, int]]]]] = None,
            headers: Optional[Dict[str, Union[str, int]]] = None,
            session: Optional[ClientSession] = None,
            **client_kwargs) -> Response:
        """
        Метод для отправки запроса

        :param url: ссылка, куда вы хотите отправить ваш запрос
        :param get_json: указывает на то, хотите ли вы получить ответ в формате json
        :param method: POST or GET(тип запроса)
        :param data:
        :param headers:
        :param session: object of aiohttp.ClientSession
        :param client_kwargs: key/value for aiohttp.ClientSession initialization
        :return: Response instance
        """
        if isinstance(headers, dict):
            headers = headers.update(self._base_headers)
        else:
            headers = self._base_headers
        if not isinstance(session, ClientSession):
            async with ClientSession(
                    timeout=self._timeout if set_timeout else DEFAULT_TIMEOUT,
                    **client_kwargs
            ) as session:
                self._session = session
                response = await self._session.request(
                    method=method,
                    url=self.url if not url else url,
                    data=self._set_auth(data) if validate_django else data,
                    headers=headers
                )
                try:
                    data = await response.json(
                        content_type="application/json"
                    )
                except ContentTypeError as ex:
                    if get_json:
                        raise RequestAuthError() from ex
                    data = await response.read()
                return Response(
                    status_code=response.status,
                    response_data=data
                )

    @staticmethod
    def _set_auth(
            data: Optional[
                Dict[str, Union[str, int, List[Union[str, int]], Tuple[Union[str, int]]]]
            ] = None) -> Optional[Dict[str, str]]:
        """
        Метод валидации для джанго апи

        :param data: It must be dict(your headers or data)
        :return: validated data or headers
        """
        try:
            from djangoProject.settings import SECRET_KEY, SECRET_CODE
        except ImportError:
            SECRET_KEY = None
            SECRET_CODE = None
        if not isinstance(data, dict):
            data = {}
        data.update(
            {
                'SECRET_KEY': SECRET_KEY,
                'SECRET_CODE': SECRET_CODE
            }
        )
        return data

    async def fetch(self, *, times: int = 10, **kwargs) -> Optional[list]:
        """

        :param times: int of quantity requests
        :param kwargs: HttpXParser._request kwargs
        :return:
        """
        results = []
        coroutines = [self._request(**kwargs) for _ in repeat(None, times)]
        for future in asyncio.as_completed(fs=coroutines):
            results.append(await future)
        # print([result.response_data for result in results])
        return results

    def fast(self):
        """
        Method to fetching faster with using faster event loop(uvloop)

        :return:
        """
        try:
            from uvloop import EventLoopPolicy
            asyncio.set_event_loop_policy(EventLoopPolicy())
        except ImportError:
            from asyncio import AbstractEventLoopPolicy as EventLoopPolicy
            asyncio.set_event_loop_policy(EventLoopPolicy())
            "Catching import error and forsake standard policy"
        return self

    def __getattr__(self, item: Any) -> Any:
        """
        Method, which can get an attribute of base_headers by this method

        :param item: key name of _base_headers dict data
        :return:
        """
        try:
            return self._base_headers.get(item)
        except KeyError:
            """Returning None"""

    def __eq__(self, other: Any) -> bool:
        """
        Method to compare instances of parsers

        :param other: other object
        :return: bool
        """
        if isinstance(other, self.__class__):
            if other.url == self.url and other._base_headers == self._base_headers:
                return True
        return False

    def __setitem__(self, key, value) -> None:
        """

        :param key: key of base_headers dict
        :param value: value of base_headers dict
        :return: None
        """
        self._base_headers.update(
            {key: value}
        )


if __name__ == '__main__':
    parser = HttpXParser()
    parser['Product'] = 'True'
    asyncio.run(parser.fast().fetch(times=1000, url='https://www.bia.pp.ua/'))

    # asyncio.run(parser.fast().fetch(1))
